package eglabs.com.crushify;

import java.util.Map;

public class TsFirestore{

    public void TsFirestore(Map<String,String> map){

    }
    public void addprofile(){}
    public void updateprofile(){}
}
