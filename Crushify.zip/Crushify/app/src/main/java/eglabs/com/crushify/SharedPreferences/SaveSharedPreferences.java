package eglabs.com.crushify.SharedPreferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import eglabs.com.crushify.FirestoreActions;

/**
 * Created by selva on 4/25/2018.
 */

public class SaveSharedPreferences {
    Context context;

    private static final String MAINSCREEN="eglabs.com.crushify.mainscreen";
    private static final String GENDER="Gender";
    private static final String LOGINDETAILS="eglabs.com.crushify.userid";
    private static final String USERID="Userid";
    private static final String PASSWORD="Password";
    public static final String PROFILEFILE="eglabs.com.crushify.profile";
    private static final String OWNPROFILE="OWNPROFILE";
    private static final String CRUSHPROFILE="CRUSHPROFILE";
    private static final String PROFILECREATED="Profilecreated";
    private static final String LANGUAGEFILE="eglabs.com.crushify.language";
    public static final String DEVICELANGUAGEEGLISH="Devicelanguageenglish";
    private static final String DEVICELANGUAGELOCAL="Devicelanguagelocal";
    private static final String DEVICELANGUAGEPREFERRED="Devicelanguagepreferred";

    SharedPreferences sp;
    public SaveSharedPreferences(Context context){
        this.context=context;
    }
    public SaveSharedPreferences(){

    }
    public void savegender(String gender){
        sp=context.getSharedPreferences(MAINSCREEN,context.MODE_PRIVATE);
        sp.edit().putString(GENDER,gender).apply();
        //Log.d("Gender",sp.getString(GENDER,null));

    }
    public Map<Object,Object> getTranslatedViewtext(){
        String keyS;
        String valueS;
        Object keyO;
        Object valueO;
        Map<String,?> translatedtextmap;
        Map<Object,Object> translateObjectMap=new HashMap<>();
       sp=context.getSharedPreferences(LANGUAGEFILE,Context.MODE_PRIVATE);
       translatedtextmap=sp.getAll();
       for (Map.Entry m:translatedtextmap.entrySet()){
           keyO=m.getKey();
           valueO=m.getValue();
           translateObjectMap.put(keyO,valueO);
       }
       return translateObjectMap;
    }
    public void saveTranslatedLanguage(Map<Object,Object> languagetranslate){
        sp=context.getSharedPreferences(LANGUAGEFILE,Context.MODE_PRIVATE);
        SharedPreferences.Editor editlang=sp.edit();
        for (Map.Entry m:languagetranslate.entrySet()){
                editlang.putString(m.getKey().toString(),m.getValue().toString());
        }
        editlang.apply();
    }
    public void savelanguage(String deviceenglanguage,String locallanguage,String preferredlanguage){
        sp=context.getSharedPreferences(LANGUAGEFILE,Context.MODE_PRIVATE);
        SharedPreferences.Editor savelang=sp.edit();
        savelang.putString(DEVICELANGUAGEEGLISH,deviceenglanguage);
        savelang.putString(DEVICELANGUAGELOCAL,locallanguage);
        savelang.putString(DEVICELANGUAGEPREFERRED,preferredlanguage);
        savelang.apply();
    }
    public String getgender(){
       String gender;
       sp=context.getSharedPreferences(MAINSCREEN,Context.MODE_PRIVATE);
       gender=sp.getString(GENDER,null);
       return gender;
    }
    public void saveuserid(String userid, String password){
        sp=context.getSharedPreferences(LOGINDETAILS,Context.MODE_PRIVATE);
        SharedPreferences.Editor edit=sp.edit();
        edit.putString(USERID,userid);
        edit.putString(PASSWORD,password);
        edit.apply();
        /*sp.edit().putString(USERID,userid).commit();
        sp.edit().putString(PASSWORD,password).commit();
*/
    }
    public String[] getlogin(){
        String[] userdetails=new String[2];
        sp=context.getSharedPreferences(LOGINDETAILS,Context.MODE_PRIVATE);
        userdetails[0]=sp.getString(USERID,null);
        userdetails[1]=sp.getString(PASSWORD,null);
        return userdetails;
    }
    public Boolean CheckSpFile(File filename){
        if (filename.exists()){
            return true;}
        else {
            return false;}
    }
    public void saveProfileStatus(String profileType){
        sp=context.getSharedPreferences(PROFILEFILE,Context.MODE_PRIVATE);
        SharedPreferences.Editor edit=sp.edit();
        switch (profileType){
            case ("OWNPROFILE"):
                edit.putString(OWNPROFILE,PROFILECREATED);
                break;
            case("CRUSHPROFILE"):
                edit.putString(CRUSHPROFILE,PROFILECREATED);
                break;
        }
        edit.apply();
    }
    public boolean fetchprofilestatus(String profiletype){
        sp=context.getSharedPreferences(PROFILEFILE,Context.MODE_PRIVATE);
        if(sp.contains(profiletype)){
            String result=sp.getString(profiletype,null);
            if (result!=null){
                return true;
            }else{
                return false;
            }
        }else{return false;}

    }
    public void savespfiles(String userId,String collection){
        FirestoreActions fsa=new FirestoreActions();
        Map<Object,Object> userdetails=new HashMap<>();
        userdetails=fsa.getFirestoredata(collection,userId);
        String Gender=userdetails
    }
}
