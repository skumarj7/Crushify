package eglabs.com.crushify;

import java.util.Map;

public class CrushFirestore {
    public void CrushFirestore(Map<String, String> map){}
    public void addprofile(){}
    public void updateprofile(){}
}
