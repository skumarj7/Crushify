package eglabs.com.crushify;

import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;

import eglabs.com.crushify.Activity.AfterLogin.CreateMaleProfile;

public class FirestoreActions {
    FirebaseFirestore db;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    private final String TAG="Firestore";
    private boolean docExists;
    public FirestoreActions(){
        db=FirebaseFirestore.getInstance();
    }
    public void saveInFirestore(String collection, String docid, Map<Object,Object> firestoredata){
        db.collection(collection).document(docid).set(firestoredata)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void avoid) {
                        Log.d("tag","DocumentSnapshot ");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error adding document", e);
                    }
                });
    }
    public Map<Object,Object> getFirestoredata(String collection,String docid){
        final Map<Object,Object> docdata=new HashMap<>();
        DocumentReference docData=db.collection(collection).document(docid);
        docData.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    final List<Object> spinnerlist=new ArrayList<>();
                    DocumentSnapshot document=task.getResult();
                    docdata.putAll(document.getData());
                } else {
                    Log.w("Error", task.getException());
                }
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("error","error"+e);
                    }});
        return docdata;
    }
    public boolean fireStoreDocExists(String collection,String docid){
        DocumentReference userref=db.collection(collection).document(docid);
        userref.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        docExists=true;
                    } else {
                        docExists=false;
                    }
                } else {
                    Log.d("tag", "get failed with ", task.getException());
                }
            }
        });

        return docExists;

    }
    public void hasdocchanged(String collection,String docid){
        final DocumentReference docRef = db.collection(collection).document(docid);
        docRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,@Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    Log.d(TAG, "Current data: " + snapshot.getData());
                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });
    }
}
