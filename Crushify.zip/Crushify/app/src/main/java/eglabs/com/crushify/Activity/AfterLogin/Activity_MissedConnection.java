package eglabs.com.crushify.Activity.AfterLogin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import eglabs.com.crushify.R;

public class Activity_MissedConnection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__missed_connection);
    }
}
