package eglabs.com.crushify;

import android.support.annotation.NonNull;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class MaleFirestore {

    public void MaleFirestore(){}
    public void MaleFirestore(Map<String,String> map){

    }
    public void addprofile(){}
    public void updateprofile(){}
    public Map<String,String> getdata(){
        Map<String,String> maleprofiledata=new Map<String, String>() {
            @Override
            public int size() {
                return 0;
            }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public boolean containsKey(Object o) {
                return false;
            }

            @Override
            public boolean containsValue(Object o) {
                return false;
            }

            @Override
            public String get(Object o) {
                return null;
            }

            @Override
            public String put(String s, String s2) {
                return null;
            }

            @Override
            public String remove(Object o) {
                return null;
            }

            @Override
            public void putAll(@NonNull Map<? extends String, ? extends String> map) {

            }

            @Override
            public void clear() {

            }

            @NonNull
            @Override
            public Set<String> keySet() {
                return null;
            }

            @NonNull
            @Override
            public Collection<String> values() {
                return null;
            }

            @NonNull
            @Override
            public Set<Entry<String, String>> entrySet() {
                return null;
            }
        };
        return maleprofiledata;
    }
}
